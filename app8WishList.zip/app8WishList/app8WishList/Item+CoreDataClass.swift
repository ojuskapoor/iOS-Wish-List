//
//  Item+CoreDataClass.swift
//  app8WishList
//
//  Created by Ojus Kapoor on 15/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

    public override func awakeFromInsert() {
        super.awakeFromInsert()
        self.created = NSDate()
    }
}

//
//  Item+CoreDataProperties.swift
//  app8WishList
//
//  Created by Ojus Kapoor on 15/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import Foundation
import CoreData


extension Item {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    @NSManaged public var detail: String?
    @NSManaged public var price: Double
    @NSManaged public var title: String?
    @NSManaged public var created: NSDate?
    @NSManaged public var toImage: Image?
    @NSManaged public var toItemType: ItemType?
    @NSManaged public var toStore: Store?

}

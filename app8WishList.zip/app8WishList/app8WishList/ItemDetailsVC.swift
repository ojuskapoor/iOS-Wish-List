//
//  ItemDetailsVC.swift
//  app8WishList
//
//  Created by Ojus Kapoor on 16/06/17.
//  Copyright © 2017 iOS Zen. All rights reserved.
//

import UIKit
import CoreData

class ItemDetailsVC: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    //UIImagePickerController delegate and UI navigationController dlegate are for picking image for the thumbNail
    var stores = [Store]()
    var itemToBeEdited: Item?
    var imagePicker = UIImagePickerController() //different Error?
    
    
    @IBOutlet weak var titleField: UITextField!
    
    @IBOutlet weak var pricefield: UITextField!
    
    @IBOutlet weak var descriptionField: UITextField!
    
    @IBOutlet weak var storePicker: UIPickerView!
    
    @IBOutlet weak var thumbImage: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        storePicker.delegate = self
        storePicker.dataSource = self
        
        imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        
        
//        let store1 = Store (context: context)
//        store1.name = "Amazon"
//        
//        let store2 = Store (context: context)
//        store2.name = "Flipkart"
//        
//        let store3 = Store (context: context)
//        store3.name = "eBay"
//        
//        let store4 = Store (context: context)
//        store4.name = "PayTm"
//        
//        let store5 = Store (context: context)
//        store5.name = "Offline Retailer"
//        
//        let store6 = Store (context: context)
//        store6.name = "Others"
//        
//        ad.saveContext()
        getStores()
        
        if itemToBeEdited != nil {
            loadItemData()
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let store = stores[row]
        return store.name
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return stores.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        //TODO
    }
    
    func getStores() {
        let fetchRequest: NSFetchRequest<Store> = Store.fetchRequest()
        
        do {
            self.stores = try context.fetch(fetchRequest)
            self.storePicker.reloadAllComponents()
        } catch {
            //Error handling
        }
    }
    
    @IBAction func donePressed(_ sender: UIButton) {
        
        var item: Item!
        
        if itemToBeEdited == nil {
            item = Item(context: context)
        } else {
            item = itemToBeEdited
        }
        
        let picture = Image(context: context)
        picture.image = thumbImage.image
        item.toImage = picture
        
        
        
        if let title = titleField.text {
            item.title = title
        }
        if let price = pricefield.text {
            item.price = (price as NSString).doubleValue
        }
        if let details = descriptionField.text {
            item.detail = details
        }
        item.toStore = stores[storePicker.selectedRow(inComponent: 0)]
        
        ad.saveContext()
        
        navigationController?.popViewController(animated: true) //dismiss the addnewItem View
    }
    
    func loadItemData() {
        
        if let item = itemToBeEdited {
            titleField.text = item.title
            pricefield.text = "\(item.price)"
            descriptionField.text = item.detail
            thumbImage.image = item.toImage?.image as? UIImage
            
            if let store = item.toStore {
                
                var index = 0
                repeat {
                    let s = stores[index]
                    if s.name == store.name {
                        storePicker.selectRow(index, inComponent: 0, animated: false)
                        break
                    }
                    index += 1
                } while (index < stores.count)
                
            }
            
        }
        
    }
    
    @IBAction func deletePressed(_ sender: Any) {
        
        if itemToBeEdited != nil {
            context.delete(itemToBeEdited!)
            ad.saveContext()
        }
        navigationController?.popViewController(animated: true)
    }
    
    
   
    @IBAction func selectImagePressed(_ sender: UIButton) {
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let img = info[UIImagePickerControllerOriginalImage] as? UIImage {
            thumbImage.image = img
            
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    
}
